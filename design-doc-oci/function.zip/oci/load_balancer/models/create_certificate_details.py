# coding: utf-8
# Copyright (c) 2016, 2019, Oracle and/or its affiliates. All rights reserved.


from oci.util import formatted_flat_dict, NONE_SENTINEL, value_allowed_none_or_none_sentinel  # noqa: F401
from oci.decorators import init_model_state_from_kwargs


@init_model_state_from_kwargs
class CreateCertificateDetails(object):
    """
    The configuration details for adding a certificate bundle to a listener.
    For more information on SSL certficate configuration, see
    `Managing SSL Certificates`__.

    **Warning:** Oracle recommends that you avoid using any confidential information when you supply string values using the API.

    __ https://docs.cloud.oracle.com/Content/Balance/Tasks/managingcertificates.htm
    """

    def __init__(self, **kwargs):
        """
        Initializes a new CreateCertificateDetails object with values from keyword arguments.
        The following keyword arguments are supported (corresponding to the getters/setters of this class):

        :param passphrase:
            The value to assign to the passphrase property of this CreateCertificateDetails.
        :type passphrase: str

        :param private_key:
            The value to assign to the private_key property of this CreateCertificateDetails.
        :type private_key: str

        :param public_certificate:
            The value to assign to the public_certificate property of this CreateCertificateDetails.
        :type public_certificate: str

        :param ca_certificate:
            The value to assign to the ca_certificate property of this CreateCertificateDetails.
        :type ca_certificate: str

        :param certificate_name:
            The value to assign to the certificate_name property of this CreateCertificateDetails.
        :type certificate_name: str

        """
        self.swagger_types = {
            'passphrase': 'str',
            'private_key': 'str',
            'public_certificate': 'str',
            'ca_certificate': 'str',
            'certificate_name': 'str'
        }

        self.attribute_map = {
            'passphrase': 'passphrase',
            'private_key': 'privateKey',
            'public_certificate': 'publicCertificate',
            'ca_certificate': 'caCertificate',
            'certificate_name': 'certificateName'
        }

        self._passphrase = None
        self._private_key = None
        self._public_certificate = None
        self._ca_certificate = None
        self._certificate_name = None

    @property
    def passphrase(self):
        """
        Gets the passphrase of this CreateCertificateDetails.
        A passphrase for encrypted private keys. This is needed only if you created your certificate with a passphrase.


        :return: The passphrase of this CreateCertificateDetails.
        :rtype: str
        """
        return self._passphrase

    @passphrase.setter
    def passphrase(self, passphrase):
        """
        Sets the passphrase of this CreateCertificateDetails.
        A passphrase for encrypted private keys. This is needed only if you created your certificate with a passphrase.


        :param passphrase: The passphrase of this CreateCertificateDetails.
        :type: str
        """
        self._passphrase = passphrase

    @property
    def private_key(self):
        """
        Gets the private_key of this CreateCertificateDetails.
        The SSL private key for your certificate, in PEM format.

        Example:

            -----BEGIN RSA PRIVATE KEY-----
            jO1O1v2ftXMsawM90tnXwc6xhOAT1gDBC9S8DKeca..JZNUgYYwNS0dP2UK
            tmyN+XqVcAKw4HqVmChXy5b5msu8eIq3uc2NqNVtR..2ksSLukP8pxXcHyb
            +sEwvM4uf8qbnHAqwnOnP9+KV9vds6BaH1eRA4CHz..n+NVZlzBsTxTlS16
            /Umr7wJzVrMqK5sDiSu4WuaaBdqMGfL5hLsTjcBFD..Da2iyQmSKuVD4lIZ
            ...
            -----END RSA PRIVATE KEY-----


        :return: The private_key of this CreateCertificateDetails.
        :rtype: str
        """
        return self._private_key

    @private_key.setter
    def private_key(self, private_key):
        """
        Sets the private_key of this CreateCertificateDetails.
        The SSL private key for your certificate, in PEM format.

        Example:

            -----BEGIN RSA PRIVATE KEY-----
            jO1O1v2ftXMsawM90tnXwc6xhOAT1gDBC9S8DKeca..JZNUgYYwNS0dP2UK
            tmyN+XqVcAKw4HqVmChXy5b5msu8eIq3uc2NqNVtR..2ksSLukP8pxXcHyb
            +sEwvM4uf8qbnHAqwnOnP9+KV9vds6BaH1eRA4CHz..n+NVZlzBsTxTlS16
            /Umr7wJzVrMqK5sDiSu4WuaaBdqMGfL5hLsTjcBFD..Da2iyQmSKuVD4lIZ
            ...
            -----END RSA PRIVATE KEY-----


        :param private_key: The private_key of this CreateCertificateDetails.
        :type: str
        """
        self._private_key = private_key

    @property
    def public_certificate(self):
        """
        Gets the public_certificate of this CreateCertificateDetails.
        The public certificate, in PEM format, that you received from your SSL certificate provider.

        Example:

            -----BEGIN CERTIFICATE-----
            MIIC2jCCAkMCAg38MA0GCSqGSIb3DQEBBQUAMIGbM..QswCQYDVQQGEwJKU
            A1UECBMFVG9reW8xEDAOBgNVBAcTB0NodW8ta3UxE..TAPBgNVBAoTCEZyY
            MRgwFgYDVQQLEw9XZWJDZXJ0IFN1cHBvcnQxGDAWB..gNVBAMTD0ZyYW5rN
            YiBDQTEjMCEGCSqGSIb3DQEJARYUc3VwcG9ydEBmc..mFuazRkZC5jb20wH
            ...
            -----END CERTIFICATE-----


        :return: The public_certificate of this CreateCertificateDetails.
        :rtype: str
        """
        return self._public_certificate

    @public_certificate.setter
    def public_certificate(self, public_certificate):
        """
        Sets the public_certificate of this CreateCertificateDetails.
        The public certificate, in PEM format, that you received from your SSL certificate provider.

        Example:

            -----BEGIN CERTIFICATE-----
            MIIC2jCCAkMCAg38MA0GCSqGSIb3DQEBBQUAMIGbM..QswCQYDVQQGEwJKU
            A1UECBMFVG9reW8xEDAOBgNVBAcTB0NodW8ta3UxE..TAPBgNVBAoTCEZyY
            MRgwFgYDVQQLEw9XZWJDZXJ0IFN1cHBvcnQxGDAWB..gNVBAMTD0ZyYW5rN
            YiBDQTEjMCEGCSqGSIb3DQEJARYUc3VwcG9ydEBmc..mFuazRkZC5jb20wH
            ...
            -----END CERTIFICATE-----


        :param public_certificate: The public_certificate of this CreateCertificateDetails.
        :type: str
        """
        self._public_certificate = public_certificate

    @property
    def ca_certificate(self):
        """
        Gets the ca_certificate of this CreateCertificateDetails.
        The Certificate Authority certificate, or any interim certificate, that you received from your SSL certificate provider.

        Example:

            -----BEGIN CERTIFICATE-----
            MIIEczCCA1ugAwIBAgIBADANBgkqhkiG9w0BAQQFAD..AkGA1UEBhMCR0Ix
            EzARBgNVBAgTClNvbWUtU3RhdGUxFDASBgNVBAoTC0..0EgTHRkMTcwNQYD
            VQQLEy5DbGFzcyAxIFB1YmxpYyBQcmltYXJ5IENlcn..XRpb24gQXV0aG9y
            aXR5MRQwEgYDVQQDEwtCZXN0IENBIEx0ZDAeFw0wMD..TUwMTZaFw0wMTAy
            ...
            -----END CERTIFICATE-----


        :return: The ca_certificate of this CreateCertificateDetails.
        :rtype: str
        """
        return self._ca_certificate

    @ca_certificate.setter
    def ca_certificate(self, ca_certificate):
        """
        Sets the ca_certificate of this CreateCertificateDetails.
        The Certificate Authority certificate, or any interim certificate, that you received from your SSL certificate provider.

        Example:

            -----BEGIN CERTIFICATE-----
            MIIEczCCA1ugAwIBAgIBADANBgkqhkiG9w0BAQQFAD..AkGA1UEBhMCR0Ix
            EzARBgNVBAgTClNvbWUtU3RhdGUxFDASBgNVBAoTC0..0EgTHRkMTcwNQYD
            VQQLEy5DbGFzcyAxIFB1YmxpYyBQcmltYXJ5IENlcn..XRpb24gQXV0aG9y
            aXR5MRQwEgYDVQQDEwtCZXN0IENBIEx0ZDAeFw0wMD..TUwMTZaFw0wMTAy
            ...
            -----END CERTIFICATE-----


        :param ca_certificate: The ca_certificate of this CreateCertificateDetails.
        :type: str
        """
        self._ca_certificate = ca_certificate

    @property
    def certificate_name(self):
        """
        **[Required]** Gets the certificate_name of this CreateCertificateDetails.
        A friendly name for the certificate bundle. It must be unique and it cannot be changed.
        Valid certificate bundle names include only alphanumeric characters, dashes, and underscores.
        Certificate bundle names cannot contain spaces. Avoid entering confidential information.

        Example: `example_certificate_bundle`


        :return: The certificate_name of this CreateCertificateDetails.
        :rtype: str
        """
        return self._certificate_name

    @certificate_name.setter
    def certificate_name(self, certificate_name):
        """
        Sets the certificate_name of this CreateCertificateDetails.
        A friendly name for the certificate bundle. It must be unique and it cannot be changed.
        Valid certificate bundle names include only alphanumeric characters, dashes, and underscores.
        Certificate bundle names cannot contain spaces. Avoid entering confidential information.

        Example: `example_certificate_bundle`


        :param certificate_name: The certificate_name of this CreateCertificateDetails.
        :type: str
        """
        self._certificate_name = certificate_name

    def __repr__(self):
        return formatted_flat_dict(self)

    def __eq__(self, other):
        if other is None:
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not self == other
